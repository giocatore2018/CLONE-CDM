# WorldCup2018
Web portal for following the world cup 2018 in football
